#include <stdio.h>
#include <stdlib.h>

#include "helloworld.h"

int main()
{
Hello();
World();

    return 0;
}
