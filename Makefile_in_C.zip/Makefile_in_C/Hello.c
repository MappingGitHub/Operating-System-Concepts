#include <stdio.h>
#include <stdlib.h>
#include "helloworld.h"

void Hello()
{

    printf("\n\nHello ");

}

