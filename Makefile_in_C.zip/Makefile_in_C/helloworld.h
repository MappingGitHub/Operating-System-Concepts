#ifndef HELLOWORLD_H_INCLUDED
#define HELLOWORLD_H_INCLUDED

void Hello();
void World();

#endif // HELLOWORLD_H_INCLUDED
